<body style="background:#ccc;">
<h1>Google form</h1>
</body>